# -*- coding: utf-8 -*-
import binascii,re
import fcntl

from decode import Decoder
de_key = 'a13b6776facce2ce24b9407fe76b7d9a2ac9f97fd11b4c03da49c5dc1bfdd4ed'
decode = Decoder(binascii.a2b_hex(de_key)).decode
from dummy import *
from miniCurl import Curl
curl = Curl()
 #Embedded file name: dedecms_path_expose.py
import re
if 0:
    i11iIiiIii
if 0:
    O0 / iIii1I11I1II1 % OoooooooOO - i1IIi

def assign(service, arg):
    if service == '''dedecms''':
        return (True, arg)
        if 0:
            II111iiii
        if 0:
            I1IiiI * Oo0Ooo / OoO0O00.OoOoOO00.o0oOOo0O0Ooo / I1ii11iIi11i


def audit(arg):
    I1IiI = arg
    o0OOO, iIiiiI, Iii1ii1II11i, iI111iI, IiII = curl.curl(I1IiI + decode("\xc3J\x11\x18\xc7\xa0\x86\xa4L\xcf'\x1b\x8b\x19\x18\xe7S\xf0\x9b\x1e\xb3$<~\xb84\xab\xae,\x97\xa0\x9f\xd7Q\x1eN\x96\xb1\x92\xba\x13\xd5=\x0f"))
    if o0OOO == 200:
        iI1Ii11111iIi = re.search(decode('\x92S\\.\x9e\xbe\x86\xbf\x04\xcd*\x15\x9a\x01N\xa7B\xf2\xd20\x8a\x0eET\xf7i\xa0\xa5;\xce\xbc\xd6\x80t<E\xad\xe1\xc7\xa2@\xd3(\t\x80\x0f\x11\xe8O\xb4\x80,\xe8y-a\xe9t\xad\xe7;\x80\xad\xcd\xd0^\x1e\x02\xda\xff\x8a\xf5\x05\xea0R\xc2X@\xf2\x11'), Iii1ii1II11i)
        if iI1Ii11111iIi:
            security_info(iI1Ii11111iIi.group(1))
            if 0:
                I1II1


if __name__ == '__main__':
    from dummy import *

#KEY---a13b6776facce2ce24b9407fe76b7d9a2ac9f97fd11b4c03da49c5dc1bfdd4ed---