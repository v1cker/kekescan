# -*- coding: utf-8 -*-
import binascii,re
import fcntl

from decode import Decoder
de_key = 'e0a46b005bc3e4b63bf33f9097023d87614810c0b71a355e0934a7bc8a862f32'
decode = Decoder(binascii.a2b_hex(de_key)).decode
from dummy import *
from miniCurl import Curl
curl = Curl()
 #Embedded file name: dotnet.py
import re
import urlparse
if 0:
    i11iIiiIii

def assign(service, arg):
    if service != '''www''':
        return
    else:
        OO0o = urlparse.urlparse(arg)
        return (True, '''%s://%s/~.aspx''' % (OO0o.scheme, OO0o.netloc))
    if 0:
        Iii1I1 + OO0O0O % iiiii % ii1I - ooO0OO000o


def audit(arg):
    ii11i = arg
    oOooOoO0Oo0O, iI1, i1I11i, OoOoOO00, I11i = curl.curl(ii11i)
    if oOooOoO0Oo0O == 404:
        if re.search(decode('\xaf\xe0^K\x0c\xe8\xab\xe5\x06\xa4'), i1I11i, re.M):
            security_warning(ii11i)
        O0O = re.search(decode('\xb5\xc1\x07j&\xad\x99\xceI\xd3\x06\xc9\xc3P\x1d\xdf\x0b,e\xb4\xc9g_3){\xfc\x97\x83\xd1\x02\x19\xaf\xf7\x1bSb\x94\xc9\x99t\xa8*\x99\xa4U\x10'), i1I11i, re.M | re.I)
        if O0O:
            security_note(decode('\xd9\xfd\x1fr{\x99\x90\xdcU\x96B\xe9\xbc"') + O0O.group(0))
            if 0:
                i11ii11iIi11i.oOoO0oo0OOOo + IiiI / Iii1ii1II11i


if __name__ == '__main__':
    from dummy import *
    exit()

#KEY---e0a46b005bc3e4b63bf33f9097023d87614810c0b71a355e0934a7bc8a862f32---