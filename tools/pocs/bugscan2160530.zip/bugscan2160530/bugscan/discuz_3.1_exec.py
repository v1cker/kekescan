# -*- coding: utf-8 -*-
import binascii,re
import fcntl

from decode import Decoder
de_key = 'a13b6776facce2ce24b9407fe76b7d9a2ac9f97fd11b4c03da49c5dc1bfdd4ed'
decode = Decoder(binascii.a2b_hex(de_key)).decode
from dummy import *
from miniCurl import Curl
curl = Curl()
#Embedded file name: discuz_3.1_exec.py
from decode import  Decoder

decode = Decoder()

def assign(service, arg):
    if service != '''discuz''':
        return
    else:
        return (True, arg)
    if 0:
        i11iIiiIii


def audit(arg):
    OO0o = arg + decode('\xd7I\x02\x07\x9f\xbe\x85\xf3H\xc49\x05\x93\x01\x0f\xa7O\xb0\x89\x0b\xb2".b\xb8')
    Oo0Ooo, O0O0OO0O0O0, iiiii, ooo0OO, II1 = curl.curl(OO0o)
    if Oo0Ooo == 200 and iiiii.find(decode('\xdfE\x19O\x8a\xa9\x8c\xa2R\xd2y\x06\x93\x19')) != -1:
        security_hole(OO0o)
        if 0:
            Oooo % OOO0O / II1Ii / Ooo
        if 0:
            iI11i11IiIiII + oo00oOOo * Oooo000o % OOo.OOO


if __name__ == '__main__':
    from dummy import *

#KEY---a13b6776facce2ce24b9407fe76b7d9a2ac9f97fd11b4c03da49c5dc1bfdd4ed---
