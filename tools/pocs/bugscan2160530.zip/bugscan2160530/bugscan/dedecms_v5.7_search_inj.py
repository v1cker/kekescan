# -*- coding: utf-8 -*-
import binascii,re
import fcntl

from decode import Decoder
de_key = 'a13b6776facce2ce24b9407fe76b7d9a2ac9f97fd11b4c03da49c5dc1bfdd4ed'
decode = Decoder(binascii.a2b_hex(de_key)).decode
from dummy import *
from miniCurl import Curl
curl = Curl()
 #Embedded file name: dedecms_v5.7_search_inj.py
if 0:
    i11iIiiIii

def assign(service, arg):
    if service == '''dedecms''':
        return (True, arg)
        if 0:
            O0 / iIii1I11I1II1 % OoooooooOO - i1IIi


def audit(arg):
    o0OO00 = arg
    oo, oo, i1iII1IiiIiI1, oo, oo = curl.curl(o0OO00 + decode("\xc3J\x11\x18\xc7\xa2\x96\xaaN\xd5!F\x85\n\x1f\xa5G\xbd\x9e\x01\xacq<4\xbe'\xab\xe4i\x9a\xb6\x99\xe5Q\r9\xdc\xea\xc4\xfa\n\xe9\x00\x1f\xb48I\xb0\x14\xa9\xdcK\xfb9\x1az\x9f4\xbc\xe81\xdf\xba\x99\xd0O+\x04\xce\xe6\xc0\xe8\x15\x93qQ\xd6YL\xac\x1b\xf3\xc8A\xe08}$\xebo\xe7\xed=\xdb\xe5\xcb\x8b\nAX\xcb\xea\xd0\xff\x02\x8fqY\xddZ[\xa4\x1b\xef\xdaN\xf7<})\xf8x\xef\xfa*\xd7\xfe\xdc\x8b\x15V\\\xc8\xfd\xc8\xf8\x15\x93zN\x92\x1bK\xbb\x08\xaa\xcb]\xef%v5\xe0c\xfb\xf2!\xdb\xee\xd7\x9b\rYX\xc0\xe2\xd8\xe8\x1e\xedr]\xc2ZW\xb9\x1b\xe3\xdeN\xff9}-\xfcx\xeb\xf6*\xd3\xfa\xdc\x8f\tVX\xcc\xfd\xcc\xf4\x15\x97~N\xc9HL\xb4\r\xf8\xcb]\xe0)j2\xe8c\xf1\xf65\xbd\xb4\xbe\xf2\x0fMH\x9a\xf8\xc8\xecs\x8e$"))
    if i1iII1IiiIiI1 and i1iII1IiiIiI1.find(decode('\x8bOE\x02\xd0\xee\xd8\xf0\n\x9bcQ\x97\x1f\x19\xacF\xa5\xdaA\xb58zs\xec{\xe7\xf61\xdf\xe6\xca')) != -1:
        security_hole(o0OO00)
        if 0:
            ooOoO0O00 * IIiIiII11i


if __name__ == '__main__':
    from dummy import *

#KEY---a13b6776facce2ce24b9407fe76b7d9a2ac9f97fd11b4c03da49c5dc1bfdd4ed---