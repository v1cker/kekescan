# -*- coding: utf-8 -*-
import binascii,re
import fcntl

from decode import Decoder
de_key = 'ab5d21d688e5789a47b617d47dc68e48a51243b1b93d3beaf737e411310753fe'
decode = Decoder(binascii.a2b_hex(de_key)).decode
from dummy import *
from miniCurl import Curl
curl = Curl()
 #Embedded file name: 1.py
import re, time
if 0:
    i11iIiiIii

def assign(service, arg):
    if service == '''feifeicms''':
        return (True, arg)
        if 0:
            O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
        if 0:
            II111iiii


def audit(arg):
    IiII1IiiIiI1 = arg + decode('\xc23E\xb3\xf0\xcb\x08\xf27\x89d\xe9\x1f\xb3\xe9;\xc6s-')
    iIiiiI1IiI1I1, o0OoOoOO00, I11i, O0O, Oo = curl.curl2(IiII1IiiIiI1)
    IiII1IiiIiI1 = arg + decode('\xc23E\xb3\xf0\xcb\x08\xf27\x89d\xe9\x10\xbf\xa3;\xcd}4\x9c\xd0Y\x16\xcf\xc5\x07\xb8?\x1f[\x01\x8b\xc5)H\xbb\xed\xb94\xf5 \xc5K') + time.strftime(decode('\x8e\x04~\xf3\xe5\xba]\xfe'), time.gmtime(time.time()))[2:] + decode('\x851N\xb1')
    iIiiiI1IiI1I1, o0OoOoOO00, I11i, O0O, Oo = curl.curl2(IiII1IiiIiI1)
    if iIiiiI1IiI1I1 == 200 and decode('\xc9(F\xa5\xeb\x84\x16') in I11i.lower():
        security_hole(decode('\xc72B\xb7\xe4\xc5\x14\xf5 \xd0~\xb8\x18\xe6\xe7&\xc6~6\xd5\xd0S\\\xd0\xd2D') % IiII1IiiIiI1)
        if 0:
            o0 * i1 * ii1IiI1i % OOooOOo / I11iIi1I / IiiIII111iI


if __name__ == '__main__':
    from dummy import *

#KEY---ab5d21d688e5789a47b617d47dc68e48a51243b1b93d3beaf737e411310753fe---