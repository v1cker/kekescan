# -*- coding: utf-8 -*-
import binascii,re
import fcntl

from decode import Decoder
de_key = 'bce1c8cb73e24b4a1518702a3080d00aad9583c2a25f4c59b4dffb06c009a25f'
decode = Decoder(binascii.a2b_hex(de_key)).decode
from dummy import *
from miniCurl import Curl
curl = Curl()
 #Embedded file name: directory_list.py
import urlparse
if 0:
    i11iIiiIii

def assign(service, arg):
    if service != '''www''':
        return
    else:
        OO0o = urlparse.urlparse(arg)
        Oo0Ooo = OO0o.path.split('''/''')
        O0O0OO0O0O0 = len(Oo0Ooo)
        if 0:
            iiI / ii1I
        if O0O0OO0O0O0 < 3:
            return (True, '''%s://%s/''' % (OO0o.scheme, OO0o.netloc))
            if 0:
                iII111iiiii11 % I1IiiI
        IIi1IiiiI1Ii = []
        for I11i11Ii in range(1, O0O0OO0O0O0 - 1):
            IIi1IiiiI1Ii.append('''%s://%s/%s/''' % (OO0o.scheme, OO0o.netloc, '''/'''.join(Oo0Ooo[1:I11i11Ii + 1])))
            if 0:
                i1iIi11iIIi1I

        return (True, IIi1IiiiI1Ii)
    if 0:
        i11ii11iIi11i.oOoO0oo0OOOo + IiiI / Iii1ii1II11i


def audit(arg):
    iI111iI = ['''To Parent Directory''',
     '''Index of /''',
     '''Directory Listing For /''',
     decode('\xd1U\x16]\x81f\xd3\xb9\x91\x83\x83\xe7\xa7r\x0e\xc0\xc3')]
    IiII = arg
    debug('''[DIR] %s''', IiII)
    iI1Ii11111iIi, i1i1II, O0oo0OO0, I1i1iiI1, I1i1iiI1 = curl.curl('''-L ''' + IiII)
    for iiIIIII1i1iI in iI111iI:
        if O0oo0OO0.find(iiIIIII1i1iI) != -1:
            security_info(IiII)
            break
            if 0:
                o00ooo0 / Oo00O0


if __name__ == '__main__':
    from dummy import *
    ooO0oooOoO0 = [decode('\x88\xdb\xf2\xf3n\xb5\x1cpgaJ\x12\x04\xb8\xc71\xd7\xa3\xb4\xb9\xd0n[(\xc3\xa9\xac%\xf6y\xdbk\xeb')]
    for IiII in ooO0oooOoO0:
        II11i = assign('''www''', IiII)[1]
        if isinstance(II11i, list):
            for Login_Get in II11i:
                audit(Login_Get)

        elif II11i:
            audit(II11i)

#KEY---bce1c8cb73e24b4a1518702a3080d00aad9583c2a25f4c59b4dffb06c009a25f---