# -*- coding: utf-8 -*-
import binascii,re
import fcntl

from decode import Decoder
de_key = '3f9632f701953df91e7b13b428d18ab7a549520831cc2a46984c83e81b933673'
decode = Decoder(binascii.a2b_hex(de_key)).decode
from dummy import *
from miniCurl import Curl
curl = Curl()
 #Embedded file name: ecshop_alipay_inj.py
if 0:
    i11iIiiIii

def assign(service, arg):
    if service == '''ecshop''':
        return (True, arg)
        if 0:
            O0 / iIii1I11I1II1 % OoooooooOO - i1IIi


def audit(arg):
    o0OO00 = arg
    oo, i1iII1IiiIiI1, iIiiiI1IiI1I1, o0OoOoOO00, I11i = curl.curl(o0OO00 + decode('M\xf3A\x87n\xfbY\xd7n\x13c\x8bK\xbe\xee\xd2\x98(>aA\xadS`\xeb9\xe1\x82~\xf0BN\x0f\xb0]\x82u\xcaI\x8b\x7f\x1fv\xebF\xbe\xb7\x92\x95yw:\x06\xa3X"\xfd>\xa6\xda+\xf1OV\r\xa6\x02\xc61\xa4\r\xc8.J#\xc7I\xb7\xef\xc4\xc6(<-\x03\xfc\x07k\xbd~\xb3\xc0'))
    if iIiiiI1IiI1I1 and iIiiiI1IiI1I1.find(decode('\x0e\xa7\x03\xc6r\xf4[\x9cm\x18r\xda')) != -1 and iIiiiI1IiI1I1.find(decode('n\xe3W\x85x\xb5x\x8bl\x14a')) != -1:
        security_hole(o0OO00)
        if 0:
            OOooo000oo0.i1 * ii1IiI1i % IIIiiIIii


if __name__ == '__main__':
    from dummy import *

#KEY---3f9632f701953df91e7b13b428d18ab7a549520831cc2a46984c83e81b933673---