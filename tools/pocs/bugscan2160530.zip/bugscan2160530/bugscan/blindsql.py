# -*- coding: utf-8 -*-
from dummy import *
from miniCurl import Curl
curl = Curl()
 # 2016.03.03 00:09:25 WITA
#Embedded file name: blindsql.py
import re
import urlparse
import urllib
import difflib
if 0:
    i11iIiiIii

def assign(service, arg):
    if service == decode(':\x02\xd6'):
        OO0o = urlparse.urlparse(arg)
        Oo0Ooo = urlparse.parse_qsl(OO0o.query)
        if OO0o.query.find(decode('s')) == -1 or len(Oo0Ooo) > 10:
            return
        return (True, arg)
    if service == decode(':\x02\xd6])?\xb1\x9b'):
        return (True, arg)
        if 0:
            OOO0O0O0ooooo % IIii1I.II1 - O00ooooo00
        if 0:
            ooOoO + iIiiiI1IiI1I1 * IIiIiII11i * o0oOOo0O0Ooo


def I1ii11iIi11i(head, body):
    return util.html2text(body, head)
    if 0:
        oO0o / OOooOOo / I11i / Ii1I
    if 0:
        iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
    if 0:
        oO0o0ooO0 - IIII / OOooOOo - oO0o0ooO0


II1i = {}
II = {}

def Oo():
    global II1i
    II1i = {}
    if 0:
        o00O0oo * II1 + IiII * IIII - i11iIiiIii - ooOoO0o


def IiiiIiI1iIiI1(a, b, threshold = 0.9):
    global II
    ooo0Oo0 = hash(a) + hash(b)
    if ooo0Oo0 in II:
        oo = II[ooo0Oo0]
    else:
        a = re.sub(decode('\x17\x0c'), decode('f'), a)
        b = re.sub(decode('\x17\x0c'), decode('f'), b)
        oo = util.str_ratio(a, b)
        II[ooo0Oo0] = oo
    return oo > threshold
    if 0:
        ooOoO0o - IIii1I - iIiiiI1IiI1I1.I1Ii111 * o00O0oo * O00ooooo00
    if 0:
        I1Ii111


def oo00000o0(a, b):
    I11i1i11i1I = []
    Iiii = difflib.SequenceMatcher()
    Iiii.set_seqs(a, b)
    OOO0O = [0, 0, 0]
    for oo0ooO0oOOOOo, oO000OoOoo00o, iiiI11, OOooO, OOoO00o in Iiii.get_opcodes():
        if oo0ooO0oOOOOo != decode('0\x1a\xde\x0c '):
            I11i1i11i1I.append(a[oO000OoOoo00o:iiiI11])

    return set(I11i1i11i1I)
    if 0:
        iIiiiI1IiI1I1 - I1Ii111 % O00ooooo00 % II1


i1iIIi1 = []
ii11iIi1I = None
if 0:
    oO0o * ooOoO0o

def O00O0O0O0(threshold, method, method_code, hash_normal, action, query, k, v, a, b, c, d):
    global ii11iIi1I

    def ooO0O(inj):
        ooiii11iII = None
        i1I111I = []
        for ooo0Oo0, i11I1IIiiIi in query:
            i11I1IIiiIi = i11I1IIiiIi + inj if ooo0Oo0 == k else i11I1IIiiIi
            i1I111I.append((ooo0Oo0, i11I1IIiiIi))
            if 0:
                II1 + IIii1I + i11iIiiIii - I11i + i11iIiiIii

        ooOoo0O = urllib.urlencode(i1I111I)
        if method == decode('\x18(\xfa'):
            ooiii11iII = decode('p\x12\x97\\?') % (action, ooOoo0O)
        elif method == decode('\x06!\xe6:'):
            ooiii11iII = decode('q\x0c\x88@e,\xf3\xceuI') % (ooOoo0O, action)
        elif method == decode('\x08\x01\xd5\x0546'):
            ooiii11iII = decode('q\x14\x88@e,\xf3\xceuI') % (ooOoo0O, action)
            if 0:
                OOO0O0O0ooooo / OOooOOo.iIiiiI1IiI1I1 * I1Ii111 - iII111i
        if ooiii11iII in II1i:
            return II1i[ooiii11iII]
        else:
            Oooo, O00o, O00, i11I1, i11I1 = curl.curl(ooiii11iII)
            debug(decode('\x0bH\x8aF!\x15\xfb\xdduIw\xfc"\x85a\xbe\xfe\x8a*\x89\x1c\xee] '), Oooo, method, k, v, inj, action)
            II1i[ooiii11iII] = (Oooo, O00, I1ii11iIi11i(O00o, O00))
            return II1i[ooiii11iII]
        if 0:
            IIii1I - o00O0oo % IIii1I - I1Ii111 * iIiiiI1IiI1I1
        if 0:
            iIiiiI1IiI1I1 - ooOoO0o * IIii1I

    O0O00o0OOO0, Ii1iIIIi1ii, o0oo0o0O00OO = ooO0O(a)
    if O0O00o0OOO0 != method_code:
        return False
    else:
        if not IiiiIiI1iIiI1(o0oo0o0O00OO, hash_normal):
            for o0oO in i1iIIi1:
                if Ii1iIIIi1ii.find(o0oO) != -1:
                    ii11iIi1I = o0oO
                    break

            return False
            if 0:
                IiII + IiII / ooOoO / IIii1I
        i1iiI11I, iiii, oO0o0O0OOOoo0 = ooO0O(b)
        if i1iiI11I != method_code:
            return False
        if not IiiiIiI1iIiI1(o0oo0o0O00OO, oO0o0O0OOOoo0):
            return False
            if 0:
                OOO0O0O0ooooo + OOO0O0O0ooooo - I11i.IIII / IIii1I
            if 0:
                O00ooooo00 % oO0o - o00O0oo + IIII
        I11iiIiii, iii11I111, OOOO00ooo0Ooo = ooO0O(c)
        if IiiiIiI1iIiI1(o0oo0o0O00OO, OOOO00ooo0Ooo, threshold):
            return False
            if 0:
                OOooOOo * OOO0O0O0ooooo + o0oOOo0O0Ooo.ooOoO / OOO0O0O0ooooo
        O000oo0O, OOOO, i11i1 = ooO0O(d)
        if not IiiiIiI1iIiI1(OOOO00ooo0Ooo, i11i1):
            return False
            if 0:
                I11i % iIiiiI1IiI1I1 + IIII / OOooOOo + iII111i * OOooOOo
        if I11iiIiii != O000oo0O:
            return False
            if 0:
                I1Ii111 + Ii1I
            if 0:
                oO0o0ooO0 - o0oOOo0O0Ooo
        Iiii = oo00000o0(o0oo0o0O00OO, OOOO00ooo0Ooo) & oo00000o0(o0oo0o0O00OO, i11i1) & (oo00000o0(oO0o0O0OOOoo0, OOOO00ooo0Ooo) & oo00000o0(oO0o0O0OOOoo0, i11i1))
        k = None
        for oOooOOo00Oo0O in Iiii:
            if k:
                if len(oOooOOo00Oo0O) > len(k):
                    k = oOooOOo00Oo0O
            else:
                k = oOooOOo00Oo0O

        if k:
            try:
                k = re.sub(decode('\x17\x12\xdbP(*\xb5\x8cn'), decode(''), k.decode(decode('2\x0e\xd0]r'), decode('!\x00\xd1\x15;6'))).strip()[:20].encode(decode('2\x0e\xd0]r'), decode('!\x00\xd1\x15;6'))
            except:
                k = repr(k)[:20]
                if 0:
                    ooOoO0o / O00ooooo00 * IIiIiII11i - oO0o0ooO0

        return (True, k)
    if 0:
        ooOoO * o0oOOo0O0Ooo % OOooOOo * ooOoO % I11i / IIII


def iIIIIii1(url, normal_hash):
    if 0:
        i11iIiiIii % IiII
    for OO00Oo in range(2):
        Oooo, O00o, O00, i11I1, i11I1 = curl.curl(decode('q\x08\x88@m"\xfe\xc6a') + url)
        hash = I1ii11iIi11i(O00o, O00)
        if Oooo > 0 and OO00Oo > 0 and not IiiiIiI1iIiI1(hash, normal_hash):
            security_warning(decode('\x05.\xfa*q\x08\xaf\x965M8\xb61\xf4v\xe0\xbe\x88l\xcc\x07') + url)
        else:
            break
            if 0:
                o00O0oo * OOooOOo + IiII + o0oOOo0O0Ooo

    for OO00Oo in range(2):
        Oooo, O00o, O00, i11I1, i11I1 = curl.curl(decode('q8\x88@m"\xfe\xc6a') + url)
        hash = I1ii11iIi11i(O00o, O00)
        if Oooo > 0 and OO00Oo > 0 and not IiiiIiI1iIiI1(hash, normal_hash):
            security_warning(decode('\x05.\xfa*q\x14\xb5\x9a+\x12\x08\xa0e\xc8}\xa9\x8f\x9dw\x93K\xbcBn') + url)
        else:
            break
            if 0:
                oO0o

    for OO00Oo in range(2):
        Oooo, O00o, O00, i11I1, i11I1 = curl.curl(decode('q=\x88@\x12w\x83\x93+Y(\xb6a\xc5\x7f\xbc\x92\x99t\xcc\x07\xf2\tk\x02\x08') + url)
        hash = I1ii11iIi11i(O00o, O00)
        if Oooo > 0 and OO00Oo > 0 and not IiiiIiI1iIiI1(hash, normal_hash):
            security_warning(decode("\x05.\xfa*q\x01\xee\xb6<M2\xb8{\xc1{\xf9\xff\xbcc\x8d\x07\x8b\x10'^D@\xc7\xc2") + url)
        else:
            break
            if 0:
                Ii1I % o00O0oo * o00O0oo


def audit(arg):
    if type(arg) == dict:
        i11iiI111I = arg[decode(' \x10\xda\r,;')]
        II11i1iIiII1 = urlparse.urlparse(arg[decode(' \x10\xda\r,;')])
        iIi1iIiii111 = arg[decode(' \x10\xda\r,;')]
        Oo0Ooo = []
        iIIIi1 = []
        for input in arg[decode('!\x05\xca\x1e#,')]:
            Oo0Ooo.append((input[decode('=\x18\xdd\x1c')], str(input[decode('>\x18\xd9\x1e%')])))
            iIIIi1.append(urllib.quote(input[decode('=\x18\xdd\x1c')]) + decode('s') + urllib.quote(str(input[decode('>\x18\xd9\x1e%')])))

        iiII1i1 = decode('|').join(iIIIi1)
    else:
        i11iiI111I = arg
        II11i1iIiII1 = urlparse.urlparse(i11iiI111I)
        iIi1iIiii111 = urlparse.urlunsplit((II11i1iIiII1.scheme,
         II11i1iIiII1.netloc,
         II11i1iIiII1.path,
         decode(''),
         decode('')))
        Oo0Ooo = urlparse.parse_qsl(II11i1iIiII1.query)
        iiII1i1 = II11i1iIiII1.query
    o00oOO0o = []
    if 0:
        Ii1I + iII111i - iII111i % ooOoO0o
    OoOO0oo0o, II11i1I11Ii1i, O000O0oOO0, i11I1, i11I1 = curl.curl(i11iiI111I)
    if OoOO0oo0o < 200 or OoOO0oo0o >= 400 or not O000O0oOO0:
        return
        if 0:
            oO0o0ooO0 % O00ooooo00.o00O0oo.I11i
    o0 = util.list_from_file(decode('4\x18\xda\x0c9&\xb5\x9a|I*\xadN\xc5e\xe3\xbf\x8ab\xdeU\xad\x1b'))
    for o0oO in o0:
        if O000O0oOO0.find(o0oO) == -1:
            i1iIIi1.append(o0oO)
            if 0:
                IIii1I + oO0o0ooO0

    i1i, I1I1iIiII1, i11i1I1, i11I1, i11I1 = curl.curl(decode('q\x0c\x88@e,\xf3\xceuI') % (iiII1i1, iIi1iIiii111))
    if i1i > 0 and i11i1I1:
        o00oOO0o.append((decode('\x06!\xe6:'), i1i, I1ii11iIi11i(I1I1iIiII1, i11i1I1)))
    o00oOO0o.append((decode('\x18(\xfa'), OoOO0oo0o, I1ii11iIi11i(II11i1I11Ii1i, O000O0oOO0)))
    ii1I, Oo0ooOo0o, Ii1i1, i11I1, i11I1 = curl.curl(decode('q\x14\x88@e,\xf3\xceuI') % (iiII1i1, iIi1iIiii111))
    if ii1I > 0 and Ii1i1:
        o00oOO0o.append((decode('\x08\x01\xd5\x0546'), ii1I, I1ii11iIi11i(Oo0ooOo0o, Ii1i1)))
        if 0:
            ooOoO
        if 0:
            i11iIiiIii.O00ooooo00 % II1 / OOO0O0O0ooooo
        if 0:
            oO0o % OOooOOo % OOooOOo.oO0o0ooO0
        if 0:
            OOooOOo * IIII + oO0o.iII111i + oO0o
    oO = [decode('\x1b#\xf2-\x05\x1c\x95\xbc\x05u\x18'), decode('\x01\x14\xda\x11\x05;\xa9\x9a+\x1e/'), decode('\x01\x14\xda\x11\x05;\xa9\x9a+\x1e+')]
    iIi1IIIi1 = [(int,
      decode('d\x18\xd1\x18pd\xec\xc8d'),
      decode('d\x18\xd1\x18pd\xfd\xd9g\x01i'),
      decode('d\x18\xd1\x18pd\xec\xc8g\x02'),
      decode('d\x18\xd1\x18pd\xec\xc8g\x01i')),
     (str,
      decode('x\\\xcc\x11!b\xe7\xc8}\x10p\xfa'),
      decode('x\\\xcc\x11!b\xe7\xc8g\x1b{\xe07\x97'),
      decode('x\\\xcc\x11!b\xe7\xc8}\x10p\xfa7'),
      decode('x\\\xcc\x11!b\xe7\xc8}\x10p\xfa7\x97')),
     (int,
      decode('a\x18\xd1\x18pd\xec\xc8'),
      decode('a\x18\xd1\x18pd\xfd\xd9g\x01'),
      decode('a\x18\xd1\x18pd\xec\xc8g'),
      decode('a\x18\xd1\x18pd\xec\xc8g\x01')),
     (str,
      decode('x\\\xcc\x11!b\xe7\xda}\x10p'),
      decode('x\\\xcc\x11!b\xe7\xc8g\x13p\xeb-\x97)'),
      decode('x\\\xcc\x11!b\xe7\xc8u\x1b{\xe07\x97'),
      decode('x\\\xcc\x11!b\xe7\xc8u\x1b{\xe07\x97)'))]
    for O0oOoOOOoOO, ii1ii11IIIiiI, O00OOOoOoo0O in o00oOO0o:
        for O000OOo00oo, oo0OOo in Oo0Ooo:
            if O000OOo00oo in oO:
                continue
            for ooOOO00Ooo, IiIIIi1iIi, ooOOoooooo, II1I, O0 in iIi1IIIi1:
                if ooOOO00Ooo == int and not re.match(decode('\x17\x0c'), oo0OOo):
                    continue
                i1II1Iiii1I11 = 1
                IIIIiiIiI = 0.5
                o00oooO0Oo = IIIIiiIiI
                if 0:
                    I1Ii111 % oO0o0ooO0 + I11i
                while o00oooO0Oo < i1II1Iiii1I11:
                    I11i1i11i1I = O00O0O0O0(o00oooO0Oo, O0oOoOOOoOO, ii1ii11IIIiiI, O00OOOoOoo0O, iIi1iIiii111, Oo0Ooo, O000OOo00oo, oo0OOo, IiIIIi1iIi, ooOOoooooo, II1I, O0)
                    if I11i1i11i1I:
                        i11I1, OOooOoooOoOo = I11i1i11i1I
                        if OOooOoooOoOo:
                            if 0:
                                o00O0oo
                            OOO00O0O = 100 - float(o00oooO0Oo - IIIIiiIiI) * 100 / (i1II1Iiii1I11 - IIIIiiIiI)
                            if OOO00O0O > 5:
                                if 0:
                                    OOO0O0O0ooooo.o00O0oo.iIiiiI1IiI1I1
                                Oo()
                                I11i1i11i1I = O00O0O0O0(o00oooO0Oo, O0oOoOOOoOO, ii1ii11IIIiiI, O00OOOoOoo0O, iIi1iIiii111, Oo0Ooo, O000OOo00oo, oo0OOo, IiIIIi1iIi, ooOOoooooo, II1I, O0)
                                if I11i1i11i1I:
                                    i11I1, OoOO = I11i1i11i1I
                                    if OoOO == OOooOoooOoOo:
                                        security_hole(decode(',\r\xcd\x11!,\xbd\x9fj\x07x\xb21\xfe;\xe7\xea\xd3%\xc7\x13\xa0>n\x1eX\x06\xd8\xc2\xe5xFa\\\x89\\?g') % (O0oOoOOOoOO,
                                         O000OOo00oo,
                                         IiIIIi1iIi,
                                         OOO00O0O,
                                         OOooOoooOoOo,
                                         i11iiI111I))
                            return
                    o00oooO0Oo += 0.01

    if ii11iIi1I:
        security_note(decode('\n:\xf9H\x05(\xb1\x9b/[g\xfc%\xdf/\xa8\xfe\x8a;') % (ii11iIi1I, i11iiI111I))
        if 0:
            IIiIiII11i


if __name__ == '__main__':
    if 0:
        I11i + Ii1I % OOO0O0O0ooooo
    if 0:
        IiII / oO0o0ooO0 - iIiiiI1IiI1I1 * IIii1I - iIiiiI1IiI1I1
    from dummy import *
    if 0:
        I11i + iIiiiI1IiI1I1 * I1Ii111 + iII111i % ooOoO0o
    if 0:
        Ii1I - IIiIiII11i + II1 + oO0o0ooO0 / oO0o
+++ okay decompyling ./4.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2016.03.03 00:09:26 WITA
